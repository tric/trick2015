puts "TRICK returns!"
